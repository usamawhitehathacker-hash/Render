import '@/app/globals.css';
import { ReactNode } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export const metadata = {
  title: 'Premium SaaS Landing Page',
  description: 'A high‑converting, premium SaaS landing page built with Next.js and Tailwind CSS.',
  openGraph: {
    title: 'Premium SaaS Landing Page',
    description: 'Experience a luxury conversion‑focused landing page with strong trust signals and powerful CTA.',
    url: 'https://example.com',
    type: 'website',
    images: [
      {
        url: '/images/hero-bg.png',
        width: 1200,
        height: 628,
        alt: 'Hero background',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Premium SaaS Landing Page',
    description: 'A high‑converting, premium SaaS landing page built with Next.js and Tailwind CSS.',
    images: ['/images/hero-bg.png'],
  },
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-background text-ivory">
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}