export interface Step {
  title: string;
  description: string;
}

export const processSteps: Step[] = [
  {
    title: 'Discovery & Clarity',
    description: 'We audit your current strategy and clarify your goals to map out the path forward.',
  },
  {
    title: 'Customised Action Plan',
    description: 'Receive a bespoke roadmap with tactical steps designed to accelerate your growth.',
  },
  {
    title: 'Implementation & Support',
    description: 'Execute your plan alongside our expert team and measure results in real time.',
  },
  {
    title: 'Scale & Optimise',
    description: 'Continuously refine strategies to scale efficiently and maximise your ROI.',
  },
];