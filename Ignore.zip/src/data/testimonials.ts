export interface Testimonial {
  quote: string;
  name: string;
  title: string;
  company: string;
}

/**
 * Placeholder testimonial data. Social proof is a powerful conversion tool
 * because people trust other customers more than brands【525820947203214†L79-L85】.
 */
export const testimonials: Testimonial[] = [
  {
    quote: 'PremiumBrand transformed our business in just 90 days — revenue grew by 42% and our client satisfaction skyrocketed.',
    name: 'Sarah Malik',
    title: 'CEO',
    company: 'TechWave Co.',
  },
  {
    quote: 'The expertise and strategic guidance we received were second to none. We\'re now closing deals we never thought possible.',
    name: 'James Aslam',
    title: 'Founder',
    company: 'FutureLabs',
  },
  {
    quote: 'If you want to play in the big leagues, PremiumBrand is the partner you need. Our growth metrics have never looked better.',
    name: 'Ayesha Khan',
    title: 'COO',
    company: 'GrowthX',
  },
];