export interface CaseStudy {
  title: string;
  result: string;
  description: string;
}

/**
 * Case study data demonstrating before‑and‑after metrics. Including real numbers
 * and outcomes helps to build credibility and trust【956608179200526†L195-L206】.
 */
export const caseStudies: CaseStudy[] = [
  {
    title: 'Scaling a SaaS startup from $500K to $5M ARR',
    result: '+900% revenue growth in 18 months',
    description: 'We partnered with the founders of a SaaS company to refine their pricing, streamline onboarding, and implement automated outreach. The result was a nine‑fold increase in recurring revenue and a dramatic boost in lifetime value.',
  },
  {
    title: 'Accelerating a coaching firm’s client acquisition',
    result: '3× more qualified leads in 60 days',
    description: 'Our targeted campaigns and high‑ticket sales system increased inbound inquiries by 300%. The firm now enjoys a waiting list and charges higher retainers.',
  },
  {
    title: 'Transforming a creative agency into a premium brand',
    result: '40% increase in project size',
    description: 'By repositioning the agency and enhancing their service packaging, we helped them attract higher‑value clients and expand project budgets by 40%.',
  },
];