export interface Benefit {
  title: string;
  description: string;
}

export const benefits: Benefit[] = [
  {
    title: 'Unparalleled Clarity',
    description: 'Gain crystal‑clear focus on your goals and the exact steps to achieve them.',
  },
  {
    title: 'Accelerated Growth',
    description: 'Break through plateaus and scale your business faster than ever before.',
  },
  {
    title: 'Elite Connections',
    description: 'Access a network of high‑achievers and thought leaders who open doors.',
  },
  {
    title: 'Peace of Mind',
    description: 'Feel confident knowing that every decision is backed by data and expertise.',
  },
];