export interface FAQ {
  question: string;
  answer: string;
}

/**
 * Frequently asked questions address common objections and provide reassurance,
 * reducing friction for potential clients【956608179200526†L155-L170】.
 */
export const faqs: FAQ[] = [
  {
    question: 'Who is PremiumBrand for?',
    answer: 'PremiumBrand is designed for ambitious entrepreneurs, coaches, and businesses ready to invest in their next level of growth. If you’re serious about scaling quickly and sustainably, you’re in the right place.',
  },
  {
    question: 'How much does it cost?',
    answer: 'Our programs are tailored to your unique needs. During your strategy call, we’ll craft a plan and pricing structure that aligns with your goals and budget.',
  },
  {
    question: 'How soon will I see results?',
    answer: 'Many clients begin to see meaningful changes within the first few weeks. Sustainable, long‑term growth typically becomes evident over the first few months of working together.',
  },
  {
    question: 'What makes PremiumBrand different?',
    answer: 'We combine premium positioning, elite mentorship, and data‑driven strategies to deliver high‑ticket results. Our commitment to excellence and our exclusive network set us apart.',
  },
];