export interface Stat {
  label: string;
  value: string;
}

export const stats: Stat[] = [
  { label: 'Clients served', value: '250+' },
  { label: 'Average ROI', value: '420%' },
  { label: 'Years of experience', value: '15+' },
  { label: 'Countries reached', value: '30+' },
];