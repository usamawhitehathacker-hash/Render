export interface Feature {
  title: string;
  description: string;
}

/**
 * Feature list. Each entry highlights a benefit rather than a technical spec,
 * reflecting best practices for landing pages that emphasise outcomes over
 * features【525820947203214†L91-L97】.
 */
export const features: Feature[] = [
  {
    title: 'Strategic Growth Planning',
    description: 'Unlock bespoke strategies tailored to scale your business and dominate your market.',
  },
  {
    title: 'Elite Coaching & Mentorship',
    description: 'Gain access to world‑class mentors who guide you through every challenge and milestone.',
  },
  {
    title: 'Exclusive Network Access',
    description: 'Join a community of high‑performing entrepreneurs and forge powerful partnerships.',
  },
  {
    title: 'Advanced Analytics Dashboard',
    description: 'Make data‑driven decisions with real‑time insights and intuitive visualisations.',
  },
];