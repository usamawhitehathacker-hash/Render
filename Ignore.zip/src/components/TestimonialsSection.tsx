import { testimonials } from '@/data/testimonials';

/**
 * Testimonials section. Quotes from satisfied clients build social proof and
 * reduce purchasing anxiety【525820947203214†L79-L85】【956608179200526†L185-L187】.
 */
export default function TestimonialsSection() {
  return (
    <section className="bg-background py-20 px-6">
      <div className="mx-auto max-w-6xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">What Our Clients Say</h2>
        <p className="mt-4 max-w-xl mx-auto text-gray-400">
          Hear from those who have already transformed their businesses with our help.
        </p>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="relative rounded-lg bg-background-secondary p-6 border border-white/5 hover:shadow-lg transition-shadow text-left"
            >
              <p className="italic text-gray-300 mb-4">“{t.quote}”</p>
              <div className="mt-4">
                <p className="text-primary font-semibold">{t.name}</p>
                <p className="text-gray-400 text-sm">
                  {t.title}, {t.company}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}