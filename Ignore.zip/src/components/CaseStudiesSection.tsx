import { caseStudies } from '@/data/caseStudies';

/**
 * Case studies section showcasing measurable results. Each card highlights
 * outcomes and demonstrates the effectiveness of the offer, which builds
 * credibility【956608179200526†L195-L206】.
 */
export default function CaseStudiesSection() {
  return (
    <section className="bg-background-secondary py-20 px-6">
      <div className="mx-auto max-w-6xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">Success Stories</h2>
        <p className="mt-4 max-w-xl mx-auto text-gray-400">
          See how our clients achieved remarkable results through our programmes.
        </p>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          {caseStudies.map((study) => (
            <div
              key={study.title}
              className="rounded-lg bg-background p-6 border border-white/5 hover:shadow-lg transition-shadow flex flex-col justify-between"
            >
              <div>
                <h3 className="text-lg font-semibold text-primary mb-2">{study.title}</h3>
                <p className="text-2xl font-bold text-ivory mb-3">{study.result}</p>
                <p className="text-gray-400 text-sm">{study.description}</p>
              </div>
              <div className="mt-6">
                {/* emphasise call to learn more */}
                <a href="#cta" className="text-primary hover:text-primary-light text-sm font-medium">
                  Book a call to see similar results →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}