/**
 * Social proof section displays client logos and trust badges. Featuring logos
 * helps build credibility and leverages the psychological effect that people
 * trust companies used by others【525820947203214†L79-L86】【956608179200526†L185-L187】.
 */
export default function SocialProofSection() {
  // Placeholder list of companies
  const logos = ['CompanyA', 'CompanyB', 'CompanyC', 'CompanyD', 'CompanyE', 'CompanyF'];
  return (
    <section className="bg-background py-16 px-6">
      <div className="mx-auto max-w-6xl text-center">
        <p className="text-sm uppercase tracking-wider text-primary mb-4">Trusted by industry leaders</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6 justify-items-center items-center">
          {logos.map((logo) => (
            <div
              key={logo}
              className="h-12 w-24 flex items-center justify-center rounded-md bg-background-secondary border border-white/5 text-gray-500 text-sm"
            >
              {logo}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}