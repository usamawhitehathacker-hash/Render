import Image from 'next/image';
import CTAButton from './CTAButton';
import { stats } from '@/data/stats';

/**
 * Hero section containing the main value proposition, supporting statement,
 * primary/secondary CTAs, and a trust bar with key stats. According to
 * conversion research, the hero should focus on a clear value proposition and
 * a single primary CTA【525820947203214†L23-L45】【525820947203214†L55-L61】.
 */
export default function HeroSection() {
  return (
    <section className="relative pt-32 pb-24 bg-gradient-to-b from-background to-background-secondary" id="hero">
      {/* Background image overlay */}
      <div className="absolute inset-0 -z-10 opacity-70">
        <Image
          src="/images/hero-bg.png"
          alt="Luxury background"
          fill
          style={{ objectFit: 'cover' }}
          priority
        />
      </div>
      <div className="mx-auto max-w-7xl px-6 text-center text-ivory">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight max-w-3xl mx-auto">
          Unlock Your Next Level of Success
        </h1>
        <p className="mt-6 text-lg md:text-xl max-w-2xl mx-auto text-gray-300">
          Partner with the experts trusted by top performers worldwide. We provide bespoke strategies, elite mentorship, and exclusive networks to help you scale faster than you imagined.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6">
          <CTAButton href="#cta">Book a Strategy Call</CTAButton>
          <CTAButton href="#cta" secondary>
            Learn More
          </CTAButton>
        </div>
        {/* Trust bar */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-xl mx-auto" aria-label="Key statistics">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-3xl font-bold text-primary">{stat.value}</p>
              <p className="mt-2 text-sm text-gray-400 uppercase tracking-wide">{stat.label}</p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-gray-500 max-w-xs mx-auto">
          These results are typical for clients who implement our proven system.
        </p>
      </div>
    </section>
  );
}