import { useState } from 'react';
import { faqs } from '@/data/faqs';

/**
 * FAQ section using an accordion UI to answer common questions and handle
 * objections. Short answers reassure visitors and reduce uncertainty【956608179200526†L155-L170】.
 */
export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  return (
    <section className="bg-background-secondary py-20 px-6" id="faq">
      <div className="mx-auto max-w-4xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">Frequently Asked Questions</h2>
        <p className="mt-4 text-gray-400">
          Have more questions? We’ve got answers.
        </p>
        <div className="mt-12 space-y-4">
          {faqs.map((faq, idx) => (
            <div key={faq.question} className="border border-white/5 rounded-lg bg-background p-4">
              <button
                className="w-full text-left flex justify-between items-center focus:outline-none"
                onClick={() => toggle(idx)}
                aria-expanded={openIndex === idx}
              >
                <span className="text-primary font-semibold">{faq.question}</span>
                <svg
                  className={`h-5 w-5 text-primary transition-transform ${openIndex === idx ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {openIndex === idx && (
                <p className="mt-3 text-gray-400 text-sm">{faq.answer}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}