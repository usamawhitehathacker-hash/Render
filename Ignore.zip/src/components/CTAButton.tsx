import { ReactNode } from 'react';
import Link from 'next/link';

interface CTAButtonProps {
  href: string;
  children: ReactNode;
  secondary?: boolean;
}

/**
 * CTAButton component to ensure consistent styling across CTAs.
 */
export default function CTAButton({ href, children, secondary }: CTAButtonProps) {
  return (
    <Link
      href={href}
      className={`inline-block rounded-md px-6 py-3 font-semibold transition-colors duration-200 ${
        secondary
          ? 'bg-background-secondary text-primary border border-primary hover:bg-primary hover:text-background'
          : 'bg-primary text-background hover:bg-primary-light'
      }`}
    >
      {children}
    </Link>
  );
}