import CTAButton from './CTAButton';

/**
 * Final call to action section. A strong closing statement and clear CTA
 * encourage visitors to take the next step now, perhaps using a subtle
 * urgency element like limited availability【956608179200526†L192-L193】.
 */
export default function FinalCTASection() {
  return (
    <section className="bg-background py-20 px-6" id="cta">
      <div className="mx-auto max-w-4xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">
          Are You Ready to Elevate Your Success?
        </h2>
        <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
          Spaces are limited. Book your strategy call today and discover what your business can achieve with our premium growth framework.
        </p>
        <div className="mt-8">
          <CTAButton href="#" >Book a Strategy Call Now</CTAButton>
        </div>
        <p className="mt-3 text-xs text-gray-500">Risk‑free: If you don’t feel the value during your call, we’ll refund your fee instantly.</p>
      </div>
    </section>
  );
}