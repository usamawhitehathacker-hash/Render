/**
 * Section describing the audience’s pain points. It highlights the status quo
 * frustrations to create a need for the offer. Emotional language should be
 * used carefully to resonate with the reader without resorting to fear tactics.
 */
export default function ProblemSection() {
  const problems = [
    {
      title: 'Stalled Growth',
      description:
        'You have ambition but keep hitting the same revenue ceiling. Traditional tactics are no longer moving the needle.',
    },
    {
      title: 'Lack of Clarity',
      description:
        'With so many options, you’re unsure which strategy will yield results. This uncertainty keeps you stuck.',
    },
    {
      title: 'Limited Network',
      description:
        'You want to connect with high‑calibre peers and mentors, but your current circle isn’t opening the right doors.',
    },
  ];
  return (
    <section className="bg-background-secondary py-20 px-6">
      <div className="mx-auto max-w-5xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">The Problem</h2>
        <p className="mt-4 max-w-xl mx-auto text-gray-400">
          The path to elite success is riddled with obstacles. These common pain points
          prevent ambitious leaders from reaching their full potential.
        </p>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          {problems.map((p) => (
            <div
              key={p.title}
              className="rounded-lg bg-background p-6 shadow-card hover:shadow-lg transition-shadow border border-white/5"
            >
              <h3 className="text-xl font-semibold text-primary mb-3">{p.title}</h3>
              <p className="text-gray-400">{p.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}