import Link from 'next/link';

/**
 * Footer component displaying navigation links, social placeholders, and legal text.
 */
export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-background-secondary text-gray-400 py-12 px-6">
      <div className="mx-auto max-w-7xl grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-ivory font-semibold mb-4">PremiumBrand</h3>
          <p className="text-sm mb-4 max-w-xs">
            Empowering high‑achievers with luxury conversion experiences and world‑class services. Join us to elevate your business.
          </p>
          <div className="flex space-x-3">
            {/* Social icons placeholders */}
            <span className="h-6 w-6 bg-primary rounded-full inline-block"></span>
            <span className="h-6 w-6 bg-primary rounded-full inline-block"></span>
            <span className="h-6 w-6 bg-primary rounded-full inline-block"></span>
          </div>
        </div>
        <div className="flex flex-col space-y-2">
          <h4 className="text-ivory font-semibold mb-2">Navigation</h4>
          <Link href="#features" className="hover:text-primary-light">Features</Link>
          <Link href="#pricing" className="hover:text-primary-light">Pricing</Link>
          <Link href="#faq" className="hover:text-primary-light">FAQ</Link>
          <Link href="#cta" className="hover:text-primary-light">Get Started</Link>
        </div>
        <div className="flex flex-col space-y-2">
          <h4 className="text-ivory font-semibold mb-2">Legal</h4>
          <Link href="#" className="hover:text-primary-light">Privacy Policy</Link>
          <Link href="#" className="hover:text-primary-light">Terms of Service</Link>
          <Link href="#" className="hover:text-primary-light">Cookie Policy</Link>
        </div>
      </div>
      <div className="mt-10 text-center text-xs text-gray-500">
        © {year} PremiumBrand. All rights reserved.
      </div>
    </footer>
  );
}