import { benefits } from '@/data/benefits';

/**
 * Benefits/outcomes section. Focuses on transformation rather than features.
 */
export default function BenefitsSection() {
  return (
    <section className="bg-background py-20 px-6">
      <div className="mx-auto max-w-6xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">Your Outcomes</h2>
        <p className="mt-4 max-w-xl mx-auto text-gray-400">
          Imagine what is possible when you operate at your highest potential.
        </p>
        <div className="mt-12 grid sm:grid-cols-2 md:grid-cols-4 gap-8">
          {benefits.map((benefit) => (
            <div
              key={benefit.title}
              className="rounded-lg bg-background-secondary p-6 border border-white/5 hover:shadow-lg transition-shadow text-left"
            >
              <h3 className="text-lg font-semibold text-primary mb-2">{benefit.title}</h3>
              <p className="text-gray-400 text-sm">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}