import { features } from '@/data/features';

/**
 * Features section displays a grid of benefits tied to our offer. Each card
 * emphasises the advantage to the user rather than the technical details.
 */
export default function FeaturesSection() {
  // Simple inline SVG icons to visually reinforce each feature
  const icons = [
    (
      <svg
        className="h-8 w-8 text-primary"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M9 11l3 3L22 4" />
        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
      </svg>
    ),
    (
      <svg
        className="h-8 w-8 text-primary"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="12" cy="12" r="10" />
        <path d="M14.31 8l5.74 9.94" />
        <path d="M9.69 8h11.48" />
        <path d="M7.38 12.94L14.31 8" />
        <path d="M7.38 12.94l5.74 9.94" />
      </svg>
    ),
    (
      <svg
        className="h-8 w-8 text-primary"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M3 3h18v18H3z" />
        <path d="M3 9h18" />
        <path d="M9 21V9" />
      </svg>
    ),
    (
      <svg
        className="h-8 w-8 text-primary"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M20 6L9 17l-5-5" />
      </svg>
    ),
  ];
  return (
    <section className="bg-background-secondary py-20 px-6" id="features">
      <div className="mx-auto max-w-6xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-ivory">What You Get</h2>
          <p className="mt-4 max-w-2xl mx-auto text-gray-400">
            Our comprehensive suite of services ensures you have everything you need to grow quickly and sustainably.
          </p>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, idx) => (
              <div
                key={feature.title}
                className="rounded-lg bg-background p-6 border border-white/5 hover:shadow-lg transition-shadow flex flex-col items-start"
              >
                <div className="mb-4">{icons[idx % icons.length]}</div>
                <h3 className="text-lg font-semibold text-primary mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm flex-grow">{feature.description}</p>
              </div>
            ))}
          </div>
      </div>
    </section>
  );
}