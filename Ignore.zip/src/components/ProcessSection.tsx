import { processSteps } from '@/data/process';

/**
 * Process section explains how the programme works in easy‑to‑understand steps.
 * A simple numbered list reduces cognitive load and clarifies the customer
 * journey【956608179200526†L155-L170】.
 */
export default function ProcessSection() {
  return (
    <section className="bg-background-secondary py-20 px-6">
      <div className="mx-auto max-w-6xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">How It Works</h2>
        <p className="mt-4 max-w-xl mx-auto text-gray-400">
          We make it simple for you to get started and achieve results.
        </p>
        <div className="mt-12 grid md:grid-cols-4 gap-8">
          {processSteps.map((step, idx) => (
            <div key={step.title} className="flex flex-col items-center text-center">
              <div className="h-10 w-10 flex items-center justify-center rounded-full bg-primary text-background mb-4 font-bold">
                {idx + 1}
              </div>
              <h3 className="text-lg font-semibold text-ivory mb-2">{step.title}</h3>
              <p className="text-gray-400 text-sm">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}