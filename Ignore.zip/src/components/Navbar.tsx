import { useEffect, useState } from 'react';
import Link from 'next/link';

/**
 * Sticky navigation bar that transitions from transparent to solid on scroll.
 * Includes a hamburger menu for mobile screens. Calls to action are repeated in
 * multiple locations to encourage conversion, consistent with research
 * suggesting persistent CTAs improve results【525820947203214†L42-L52】.
 */
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-colors duration-300 ${
        scrolled ? 'bg-background/90 backdrop-blur border-b border-white/5' : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/" className="text-lg font-bold text-primary">
          PremiumBrand
        </Link>
        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <Link href="#features" className="hover:text-primary-light transition-colors">
            Features
          </Link>
          <Link href="#pricing" className="hover:text-primary-light transition-colors">
            Pricing
          </Link>
          <Link href="#faq" className="hover:text-primary-light transition-colors">
            FAQ
          </Link>
          <Link
            href="#cta"
            className="rounded-md bg-primary px-5 py-2 text-background font-semibold shadow hover:bg-primary-light transition-colors"
          >
            Book a Strategy Call
          </Link>
        </div>
        {/* Mobile Hamburger */}
        <button
          className="md:hidden text-ivory focus:outline-none"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <svg
            className="h-6 w-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d={
                menuOpen
                  ? 'M6 18L18 6M6 6l12 12'
                  : 'M4 6h16M4 12h16M4 18h16'
              }
            />
          </svg>
        </button>
      </nav>
      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div className="md:hidden bg-background/95 backdrop-blur absolute inset-x-0 top-full z-40 w-full">
          <div className="flex flex-col space-y-4 px-6 py-6">
            <Link href="#features" onClick={() => setMenuOpen(false)} className="hover:text-primary-light">
              Features
            </Link>
            <Link href="#pricing" onClick={() => setMenuOpen(false)} className="hover:text-primary-light">
              Pricing
            </Link>
            <Link href="#faq" onClick={() => setMenuOpen(false)} className="hover:text-primary-light">
              FAQ
            </Link>
            <Link
              href="#cta"
              onClick={() => setMenuOpen(false)}
              className="rounded-md bg-primary px-5 py-2 text-background font-semibold shadow hover:bg-primary-light"
            >
              Book a Strategy Call
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}