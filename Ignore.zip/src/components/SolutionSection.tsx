/**
 * Solution section explains how the offer works and why it's better than the
 * status quo. Clear and concise messaging emphasises benefits and outcomes
 * rather than features, echoing best practices for SaaS landing pages【525820947203214†L91-L97】.
 */
export default function SolutionSection() {
  const solutions = [
    {
      title: 'Tailored Growth Framework',
      description:
        'We assess your unique situation and craft a customised strategy designed to break through stagnation and accelerate growth.',
    },
    {
      title: 'Hands‑On Expert Guidance',
      description:
        'Our elite mentors work with you personally to implement best practices, avoiding trial and error and saving you months of frustration.',
    },
    {
      title: 'High‑Impact Community',
      description:
        'Surround yourself with other high achievers. Our network supports your growth with partnerships, collaborations and shared resources.',
    },
  ];
  return (
    <section className="bg-background py-20 px-6">
      <div className="mx-auto max-w-6xl text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-ivory">Our Solution</h2>
        <p className="mt-4 max-w-2xl mx-auto text-gray-400">
          We combine strategic planning, expert mentorship, and an exclusive network to deliver a transformative growth experience tailored to you.
        </p>
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          {solutions.map((s) => (
            <div
              key={s.title}
              className="rounded-lg bg-background-secondary p-6 border border-white/5 hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-semibold text-primary mb-3">{s.title}</h3>
              <p className="text-gray-400">{s.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}