import type { Config } from "tailwindcss";

/**
 * Tailwind configuration for the luxury dark theme.
 *
 * This file extends the default theme with a deep charcoal background,
 * elegant gold accents, and optional emerald and blue support colours. These
 * colours are inspired by research on high‑converting SaaS landing pages
 * which emphasises clear visual hierarchy and trust building through
 * consistent branding【525820947203214†L23-L45】【956608179200526†L155-L170】.
 */
const config: Config = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        background: {
          DEFAULT: "#0B0B0F", // deep charcoal base
          secondary: "#18181C", // slightly lighter surface
        },
        primary: {
          DEFAULT: "#D6B36A", // gold/champagne accent
          light: "#E9CFA1",
          dark: "#B7924F",
        },
        ivory: "#F5F3EC",
        emerald: "#014D40",
        blue: "#12385A",
      },
      fontFamily: {
        sans: [
          "Inter", // Inter provides a modern, clean sans serif look
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
      },
      boxShadow: {
        card: "0 4px 16px rgba(0, 0, 0, 0.3)",
      },
    },
  },
  plugins: [],
};

export default config;